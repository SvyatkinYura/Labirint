#pragma once

const int KOLICHESTVO_KNOPOK = 9;
const int SHIRINA_KNOPKI = 160;
const int VISOTA_KNOPKI = 40;
const int SHIRINA_OBJ = 20;
